/**
 * 
 */
package org.richfaces;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;

import org.apache.xml.resolver.tools.ResolvingParser;
import org.apache.xml.resolver.tools.ResolvingXMLFilter;
import org.apache.xml.resolver.tools.ResolvingXMLReader;
import org.xml.sax.ContentHandler;
import org.xml.sax.DTDHandler;
import org.xml.sax.EntityResolver;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.Parser;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;

import com.icl.saxon.aelfred.SAXParserFactoryImpl;

/**
 * @author Nick - mailto:nbelaevski@exadel.com
 * created 11.02.2007
 * 
 */
public class SaxParserFactory extends SAXParserFactoryImpl {
	public SaxParserFactory() {
		super();
	}
	
	public SAXParser newSAXParser() throws ParserConfigurationException {
		final SAXParser parser = super.newSAXParser();
		
		return new SAXParser() {
			public Parser getParser() throws SAXException {
				Parser parser2 = parser.getParser();
				parser2.setEntityResolver(DocTransformerFactory.catalogResolver);
				parser2.setDTDHandler(new ResolvingParser());
				return parser2;
			}

			public Object getProperty(String name)
					throws SAXNotRecognizedException, SAXNotSupportedException {
				return parser.getProperty(name);
			}

			public XMLReader getXMLReader() throws SAXException {
				final XMLReader reader = parser.getXMLReader();
				
				return new Reader(reader);
			}

			public boolean isNamespaceAware() {
				return parser.isNamespaceAware();
			}

			public boolean isValidating() {
				return parser.isValidating();
			}

			public void setProperty(String name, Object value)
					throws SAXNotRecognizedException, SAXNotSupportedException {

				parser.setProperty(name, value);
			}
		};
	}
}

class Reader implements XMLReader {
	private XMLReader reader;

	public Reader(XMLReader reader) {
		super();
		this.reader = reader;
		this.reader.setEntityResolver(this.getEntityResolver());
	}

	public ContentHandler getContentHandler() {
		return reader.getContentHandler();
	}

	public DTDHandler getDTDHandler() {
		return reader.getDTDHandler();
	}

	public EntityResolver getEntityResolver() {
		return DocTransformerFactory.catalogResolver;
	}

	public ErrorHandler getErrorHandler() {
		return reader.getErrorHandler();
	}

	public boolean getFeature(String name) throws SAXNotRecognizedException,
			SAXNotSupportedException {
		return reader.getFeature(name);
	}

	public Object getProperty(String name) throws SAXNotRecognizedException,
			SAXNotSupportedException {
		return reader.getProperty(name);
	}

	public void parse(InputSource input) throws IOException, SAXException {
		reader.parse(input);
	}

	public void parse(String systemId) throws IOException, SAXException {
		reader.parse(systemId);
	}

	public void setContentHandler(ContentHandler handler) {
		reader.setContentHandler(handler);
	}

	public void setDTDHandler(DTDHandler handler) {
		reader.setDTDHandler(handler);
	}

	public void setEntityResolver(EntityResolver resolver) {
		//reader.setEntityResolver(resolver);
	}

	public void setErrorHandler(ErrorHandler handler) {
		reader.setErrorHandler(handler);
	}

	public void setFeature(String name, boolean value)
			throws SAXNotRecognizedException, SAXNotSupportedException {
		reader.setFeature(name, value);
	}

	public void setProperty(String name, Object value)
			throws SAXNotRecognizedException, SAXNotSupportedException {
		reader.setProperty(name, value);
	}
}
