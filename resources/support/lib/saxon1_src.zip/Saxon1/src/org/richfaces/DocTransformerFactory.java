/**
 * 
 */
package org.richfaces;

import javax.xml.transform.URIResolver;

import org.apache.xml.resolver.tools.CatalogResolver;
import org.apache.xml.resolver.tools.ResolvingXMLReader;

import com.icl.saxon.FeatureKeys;
import com.icl.saxon.TransformerFactoryImpl;

/**
 * @author Nick - mailto:nbelaevski@exadel.com
 * created 11.02.2007
 * 
 */
public class DocTransformerFactory extends TransformerFactoryImpl {
	protected static final CatalogResolver catalogResolver = new CatalogResolver();
	
	public DocTransformerFactory() {
		super();

		setURIResolver(catalogResolver);
		
		setAttribute(FeatureKeys.SOURCE_PARSER_CLASS, ResolvingXMLReader.class.getName());
		setAttribute(FeatureKeys.STYLE_PARSER_CLASS, ResolvingXMLReader.class.getName());
	}

	public void setURIResolver(URIResolver arg0) {
		if (arg0 instanceof CatalogResolver) {
			super.setURIResolver(arg0);
		}
	}
}
